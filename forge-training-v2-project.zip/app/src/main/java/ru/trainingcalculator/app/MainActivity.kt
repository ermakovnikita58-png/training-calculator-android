package ru.trainingcalculator.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback

class MainActivity : ComponentActivity() {
    private lateinit var webView: WebView
    private var chooserCallback: ValueCallback<Array<Uri>>? = null
    private var pendingBytes: ByteArray? = null
    private var pendingMime = "application/octet-stream"
    private var pendingName = "forge-backup.json"

    private val picker = registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()) { result ->
        val callback = chooserCallback
        if (callback != null) {
            val uri = if (result.resultCode == Activity.RESULT_OK) result.data?.data else null
            callback.onReceiveValue(if (uri != null) arrayOf(uri) else null)
            chooserCallback = null
            return@registerForActivityResult
        }
        if (result.resultCode == Activity.RESULT_OK) {
            val uri = result.data?.data
            val bytes = pendingBytes
            if (uri != null && bytes != null) {
                try { contentResolver.openOutputStream(uri)?.use { it.write(bytes) }; Toast.makeText(this, "Резервная копия сохранена", Toast.LENGTH_SHORT).show() }
                catch (_: Exception) { Toast.makeText(this, "Не удалось сохранить файл", Toast.LENGTH_LONG).show() }
            }
        }
        pendingBytes = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (::webView.isInitialized) webView.evaluateJavascript("(function(){var m=document.getElementById('modalback');if(m&&m.classList.contains('show')){m.classList.remove('show');return 'modal'}var p=document.querySelector('.page.active');if(p&&p.id!=='home'&&p.id!=='profile'){showPage('home');return 'page'}return 'exit'})()") { result -> if (result == "\"exit\"") finish() }
                else finish()
            }
        })
        webView = WebView(this)
        setContentView(webView)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = true
        webView.settings.setSupportMultipleWindows(false)
        webView.addJavascriptInterface(Bridge(), "AndroidBridge")
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return false
                return uri.scheme != "file" && uri.scheme != "about" && uri.scheme != "data" && uri.scheme != "blob"
            }
        }
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(view: WebView?, callback: ValueCallback<Array<Uri>>?, params: FileChooserParams?): Boolean {
                chooserCallback?.onReceiveValue(null); chooserCallback = callback
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "application/json" }
                return try { picker.launch(intent); true } catch (_: Exception) { chooserCallback = null; callback?.onReceiveValue(null); false }
            }
        }
        webView.loadUrl("file:///android_asset/index.html")
    }

    inner class Bridge {
        @JavascriptInterface fun saveBlob(filename: String, base64: String, mimeType: String) {
            runOnUiThread {
                try {
                    pendingBytes = Base64.decode(base64, Base64.DEFAULT)
                    pendingMime = mimeType.ifBlank { "application/octet-stream" }
                    pendingName = filename.substringAfterLast('/').substringAfterLast('\\').ifBlank { "forge-backup.json" }
                    val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = pendingMime; putExtra(Intent.EXTRA_TITLE, pendingName) }
                    picker.launch(intent)
                } catch (_: Exception) { pendingBytes = null; Toast.makeText(this@MainActivity, "Не удалось подготовить экспорт", Toast.LENGTH_LONG).show() }
            }
        }
    }
    override fun onDestroy() { if (::webView.isInitialized) { webView.removeJavascriptInterface("AndroidBridge"); webView.destroy() }; super.onDestroy() }
}
